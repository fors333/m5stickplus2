
# M5StickCPlus2

## Basic library for M5Stack M5StickCPlus2 Board 


License
----------------
M5GFX : [MIT](https://github.com/m5stack/M5GFX/blob/master/LICENSE)  
M5Unified : [MIT](https://github.com/m5stack/M5Unified/blob/master/LICENSE)  
Arduino-IRremote : [MIT](https://github.com/Arduino-IRremote/Arduino-IRremote/blob/master/LICENSE)  
